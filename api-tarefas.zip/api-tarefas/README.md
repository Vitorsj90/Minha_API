# API de Gerenciamento de Tarefas

## Como executar
```bash
npm install
node src/app.js
```

## Endpoints

- GET `/tarefas`
- GET `/tarefas?concluida=true`
- GET `/tarefas/:id`
- POST `/tarefas`
- PUT `/tarefas/:id`
- PATCH `/tarefas/:id/concluir`
- DELETE `/tarefas/:id`

Campos obrigatórios: `titulo`, `descricao`, `concluida`
