const express = require('express');
const morgan = require('morgan');
const tarefasRoutes = require('./routes/tarefasRoutes');

const app = express();
app.use(express.json());
if (process.env.NODE_ENV !== 'production') app.use(morgan('dev'));

app.use(tarefasRoutes);

app.use((req, res) => res.status(404).json({ erro: 'Rota não encontrada.' }));

app.listen(3000, () => {
  console.log('API rodando na porta 3000 🚀');
});
