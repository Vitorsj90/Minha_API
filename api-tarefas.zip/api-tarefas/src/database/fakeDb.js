const tarefas = [];
module.exports = { tarefas };
