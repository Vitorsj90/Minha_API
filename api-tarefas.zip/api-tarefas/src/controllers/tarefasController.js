const service = require('../services/tarefasService');
const { log } = require('../utils/logger');

module.exports = {
  criar(req, res) {
    try {
      const tarefa = service.adicionarTarefa(req.body);
      log('Tarefa criada com sucesso.');
      return res.status(201).json(tarefa);
    } catch (e) {
      return res.status(500).json({ erro: 'Erro ao criar tarefa.' });
    }
  },

  listar(req, res) {
    const { concluida } = req.query;
    const tarefas = service.listarTarefas(concluida);
    return res.json(tarefas);
  },

  buscar(req, res) {
    const tarefa = service.buscarPorId(req.params.id);
    if (!tarefa) return res.status(404).json({ erro: 'Tarefa não encontrada.' });
    return res.json(tarefa);
  },

  atualizar(req, res) {
    const tarefa = service.atualizarTarefa(req.params.id, req.body);
    if (!tarefa) return res.status(404).json({ erro: 'Tarefa não encontrada.' });
    log('Tarefa atualizada.');
    return res.json(tarefa);
  },

  deletar(req, res) {
    const sucesso = service.deletarTarefa(req.params.id);
    if (!sucesso) return res.status(404).json({ erro: 'Tarefa não encontrada.' });
    log('Tarefa deletada.');
    return res.status(204).send();
  },

  concluir(req, res) {
    const tarefa = service.concluirTarefa(req.params.id);
    if (!tarefa) return res.status(404).json({ erro: 'Tarefa não encontrada.' });
    log('Tarefa marcada como concluída.');
    return res.json(tarefa);
  }
};
