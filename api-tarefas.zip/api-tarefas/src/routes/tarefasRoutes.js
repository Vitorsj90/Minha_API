const express = require('express');
const controller = require('../controllers/tarefasController');
const validateTarefa = require('../middlewares/validateTarefa');

const router = express.Router();

router.get('/tarefas', controller.listar);
router.get('/tarefas/:id', controller.buscar);
router.post('/tarefas', validateTarefa, controller.criar);
router.put('/tarefas/:id', validateTarefa, controller.atualizar);
router.patch('/tarefas/:id/concluir', controller.concluir);
router.delete('/tarefas/:id', controller.deletar);

module.exports = router;
