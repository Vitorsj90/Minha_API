const { tarefas } = require('../database/fakeDb');
const { v4: uuidv4 } = require('uuid');

function adicionarTarefa(data) {
  const novaTarefa = { id: uuidv4(), ...data };
  tarefas.push(novaTarefa);
  return novaTarefa;
}

function listarTarefas(filtroConcluida) {
  return filtroConcluida !== undefined
    ? tarefas.filter(t => t.concluida === (filtroConcluida === 'true'))
    : tarefas;
}

function buscarPorId(id) {
  return tarefas.find(t => t.id === id);
}

function atualizarTarefa(id, data) {
  const index = tarefas.findIndex(t => t.id === id);
  if (index === -1) return null;
  tarefas[index] = { ...tarefas[index], ...data };
  return tarefas[index];
}

function deletarTarefa(id) {
  const index = tarefas.findIndex(t => t.id === id);
  if (index === -1) return false;
  tarefas.splice(index, 1);
  return true;
}

function concluirTarefa(id) {
  const tarefa = buscarPorId(id);
  if (!tarefa) return null;
  tarefa.concluida = true;
  return tarefa;
}

module.exports = {
  adicionarTarefa,
  listarTarefas,
  buscarPorId,
  atualizarTarefa,
  deletarTarefa,
  concluirTarefa
};
